import 'package:flutter/material.dart';
import 'package:flutterquiz/app/app.dart';

//Elite quiz - v-2.0.5

void main() async {
  runApp(await initializeApp());
}
